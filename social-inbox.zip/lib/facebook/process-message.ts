import "server-only";

import {
  getFacebookCustomerProfile,
} from "@/lib/facebook/get-facebook-customer-profile";
import { getFacebookMessageContent } from "@/lib/facebook/get-message-content";
import {
  getConversationMessagePreview,
} from "@/lib/inbox/conversation-preview";
import { supabaseAdmin } from "@/lib/supabase/admin";
import type { FacebookMessagingEvent } from "@/types/facebook";

function toIso(timestamp?: number) {
  return timestamp
    ? new Date(timestamp).toISOString()
    : new Date().toISOString();
}

export async function processFacebookMessage(
  event: FacebookMessagingEvent,
) {
  const messageId = event.message?.mid;
  const senderId = event.sender?.id;
  const recipientId = event.recipient?.id;

  if (!messageId || !senderId || !recipientId) {
    return;
  }

  const isEcho = event.message?.is_echo === true;

  /*
   * V3.11.30.2 — Multi-Page incoming Messenger fix.
   *
   * Do NOT compare this Page to legacy FACEBOOK_PAGE_ID.
   * The webhook recipient is the authoritative Page for incoming
   * customer messages, and every active connected Page is resolved
   * from social_accounts below.
   */
  const pageId = isEcho ? senderId : recipientId;
  const customerId = isEcho ? recipientId : senderId;

  const { data: existingMessage, error: existingMessageError } =
    await supabaseAdmin
      .from("messages")
      .select("id")
      .eq("platform_message_id", messageId)
      .maybeSingle();

  if (existingMessageError) {
    throw new Error(existingMessageError.message);
  }

  if (existingMessage) {
    return;
  }

  const { data: socialAccount, error: accountError } =
    await supabaseAdmin
      .from("social_accounts")
      .select("id,business_id,account_name")
      .eq("platform", "facebook")
      .eq("platform_account_id", pageId)
      .eq("is_active", true)
      .maybeSingle();

  if (accountError) {
    throw new Error(accountError.message);
  }

  if (!socialAccount) {
    throw new Error(
      `Active Facebook Page ${pageId} was not found in social_accounts.`,
    );
  }

  console.log(
    "[Tenh Facebook Message] Processing Messenger event.",
    {
      pageId,
      pageName: socialAccount.account_name ?? null,
      customerId,
      messageId,
      isEcho,
    },
  );

  const messageTime = toIso(event.timestamp);

  /*
   * Start customer profile enrichment immediately, but do not wait for Meta
   * before saving the message. The messages INSERT is the Realtime fast path
   * for the Inbox and alert sound, so profile lookup must never block it.
   */
  const customerProfilePromise =
    !isEcho
      ? getFacebookCustomerProfile({
          pageId,
          customerId,
          latestMessageId: messageId,
        }).catch((error) => {
          console.warn(
            "[Tenh Facebook Message] Customer profile enrichment failed; message delivery continues.",
            error instanceof Error
              ? error.message
              : "Unknown profile enrichment error",
          );

          return null;
        })
      : Promise.resolve(null);

  /*
   * Upsert only the stable identity now. Existing name/photo values are not
   * overwritten because those optional columns are intentionally omitted.
   */
  const contactPayload:
    Record<
      string,
      unknown
    > = {
    business_id:
      socialAccount.business_id,
    platform:
      "facebook",
    platform_user_id:
      customerId,
    last_contact_at:
      messageTime,
    updated_at:
      new Date().toISOString(),
  };

  const { data: contact, error: contactError } =
    await supabaseAdmin
      .from("contacts")
      .upsert(
        contactPayload,
        {
          onConflict:
            "business_id,platform,platform_user_id",
        },
      )
      .select("id")
      .single();

  if (contactError || !contact) {
    throw new Error(
      contactError?.message ??
        "Unable to create contact.",
    );
  }



  const { data: conversation, error: conversationError } =
    await supabaseAdmin
      .from("conversations")
      .upsert(
        {
          business_id: socialAccount.business_id,
          social_account_id: socialAccount.id,
          contact_id: contact.id,
          platform: "facebook",
          status: "open",
          updated_at: new Date().toISOString(),
        },
        {
          onConflict:
            "social_account_id,contact_id",
        },
      )
      .select("id,unread_count")
      .single();

  if (conversationError || !conversation) {
    throw new Error(
      conversationError?.message ??
        "Unable to create conversation.",
    );
  }

  const content =
    getFacebookMessageContent(event);

  const { error: messageError } =
    await supabaseAdmin.from("messages").insert({
      business_id: socialAccount.business_id,
      conversation_id: conversation.id,
      platform_message_id: messageId,
      sender_platform_id: senderId,
      recipient_platform_id: recipientId,
      direction: isEcho ? "outgoing" : "incoming",
      message_type: content.messageType,
      message_text: content.messageText,
      attachment_url: content.attachmentUrl,
      is_echo: isEcho,
      raw_payload: event,
      platform_created_at: messageTime,
    });

  if (messageError) {
    throw new Error(messageError.message);
  }

  const unreadCount = isEcho
    ? (conversation.unread_count ?? 0)
    : (conversation.unread_count ?? 0) + 1;

  const { error: updateError } =
    await supabaseAdmin
      .from("conversations")
      .update({
        last_message_text:
          getConversationMessagePreview({
            direction: isEcho
              ? "outgoing"
              : "incoming",
            messageType:
              content.messageType,
            messageText:
              content.messageText,
          }),
        last_message_at: messageTime,
        unread_count: unreadCount,
        updated_at: new Date().toISOString(),
      })
      .eq("id", conversation.id);

  if (updateError) {
    throw new Error(updateError.message);
  }

  const customerProfile =
    await customerProfilePromise;

  const customerName =
    customerProfile?.fullName ?? null;
  const customerProfilePictureUrl =
    customerProfile?.profilePictureUrl ?? null;

  if (customerName || customerProfilePictureUrl) {
    const profileUpdate:
      Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };

    if (customerName) {
      profileUpdate.full_name = customerName;
    }

    if (customerProfilePictureUrl) {
      profileUpdate.profile_picture_url =
        customerProfilePictureUrl;
    }

    const { error: profileUpdateError } =
      await supabaseAdmin
        .from("contacts")
        .update(profileUpdate)
        .eq("id", contact.id);

    if (profileUpdateError) {
      console.warn(
        "[Tenh Facebook Message] Message was saved, but customer profile update failed:",
        profileUpdateError.message,
      );
    } else {
      console.log(
        "[Tenh Facebook Message] Messenger customer profile enriched after Realtime message save.",
        {
          pageId,
          customerId,
          customerName,
          hasProfilePicture: Boolean(
            customerProfilePictureUrl,
          ),
        },
      );
    }
  }
}