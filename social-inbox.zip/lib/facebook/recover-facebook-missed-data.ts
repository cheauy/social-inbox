import "server-only";

import {
  facebookGraphJsonWithTokenRecovery,
} from "@/lib/facebook/facebook-connection-health";
import {
  processFacebookComment,
  type FacebookFeedCommentValue,
} from "@/lib/facebook/process-comment";
import { processFacebookMessage } from "@/lib/facebook/process-message";
import { supabaseAdmin } from "@/lib/supabase/admin";
import type {
  FacebookAttachment,
  FacebookMessagingEvent,
} from "@/types/facebook";

type GraphError = {
  message?: string;
  code?: number;
  error_subcode?: number;
};

type GraphPayload = {
  error?: GraphError;
  [key: string]: unknown;
};

type GraphMessageRef = {
  id?: string;
  created_time?: string;
};

type GraphConversation = {
  id?: string;
  updated_time?: string;
  messages?: {
    data?: GraphMessageRef[];
  };
};

type GraphConversationList = GraphPayload & {
  data?: GraphConversation[];
};

type GraphMessageParticipant = {
  id?: string;
  name?: string;
  username?: string;
};

type GraphAttachment = {
  type?: string;
  mime_type?: string;
  name?: string;
  file_url?: string;
  image_data?: {
    url?: string;
  };
  video_data?: {
    url?: string;
  };
  audio_data?: {
    url?: string;
  };
  payload?: {
    url?: string;
    sticker_id?: number;
  };
};

type GraphMessageDetail = GraphPayload & {
  id?: string;
  created_time?: string;
  from?: GraphMessageParticipant;
  to?: {
    data?: GraphMessageParticipant[];
  };
  message?: string;
  attachments?: {
    data?: GraphAttachment[];
  };
};

type GraphPost = {
  id?: string;
  created_time?: string;
};

type GraphPostList = GraphPayload & {
  data?: GraphPost[];
};

type GraphComment = {
  id?: string;
  message?: string;
  created_time?: string;
  from?: {
    id?: string;
    name?: string;
  };
  parent?: {
    id?: string;
  };
};

type GraphCommentList = GraphPayload & {
  data?: GraphComment[];
};

export type FacebookRecoveryMode = "watchdog" | "reconnect";

export type FacebookRecoveryResult = {
  messenger: {
    candidates: number;
    recovered: number;
    failed: number;
    truncated: boolean;
  };
  comments: {
    candidates: number;
    recovered: number;
    failed: number;
    truncated: boolean;
  };
  tokenRepaired: boolean;
};

function cleanString(value: unknown) {
  return typeof value === "string" && value.trim()
    ? value.trim()
    : null;
}

function dateToMs(value?: string | null) {
  if (!value) {
    return null;
  }

  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function toUnixSeconds(value?: string | null) {
  const parsed = dateToMs(value);
  return parsed === null
    ? Math.floor(Date.now() / 1000)
    : Math.floor(parsed / 1000);
}

/*
 * A day is the default in both modes.
 *
 * Reconnect used to fall back to a week, which meant any caller that forgot to
 * pass a window silently pulled seven days of conversations a shop had already
 * answered elsewhere. Both current callers pass one explicitly, so this was a
 * trap rather than a live fault -- but it is the kind that goes off later,
 * quietly, in the one place nobody re-reads.
 *
 * The ceiling stays a week so a longer window remains possible on purpose,
 * through FACEBOOK_RECONNECT_RECOVERY_LOOKBACK_MINUTES. It is no longer
 * possible by accident.
 */
/*
 * Minutes elapsed since midnight, where the shop is.
 *
 * "Today" has to mean the customer's today. Cambodia runs UTC+7, so a UTC day
 * boundary would drop everything before 07:00 local into yesterday and a shop
 * opening at eight would find its whole morning missing. The analytics routes
 * already hit this and solved it the same way.
 *
 * The timezone is configurable but defaults to the market TENH serves, because
 * a wrong default here is invisible: the inbox simply looks emptier than it
 * should, with nothing to say why.
 */
export function minutesSinceLocalMidnight(
  timeZone = process.env.TENH_TIMEZONE?.trim() ||
    "Asia/Phnom_Penh",
) {
  try {
    const parts = new Intl.DateTimeFormat("en-GB", {
      timeZone,
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).formatToParts(new Date());

    const hour = Number(
      parts.find((part) => part.type === "hour")?.value ?? "0",
    );
    const minute = Number(
      parts.find((part) => part.type === "minute")?.value ?? "0",
    );

    if (!Number.isFinite(hour) || !Number.isFinite(minute)) {
      return 1_440;
    }

    /*
     * Just after midnight this is a handful of minutes, which the caller's
     * own floor widens back out. Reaching slightly into last night is the
     * right way to be wrong -- a message sent at 23:58 is still worth
     * answering at 00:05.
     */
    return hour * 60 + minute;
  } catch {
    /* An invalid timezone should not empty the inbox. */
    return 1_440;
  }
}

function clampLookbackMinutes(
  value?: number,
  mode: FacebookRecoveryMode = "watchdog",
) {
  const fallback = mode === "reconnect" ? 1_440 : 180;
  const maximum = mode === "reconnect" ? 10_080 : 1_440;

  if (!Number.isFinite(value)) {
    return fallback;
  }

  return Math.min(maximum, Math.max(60, Math.round(value as number)));
}

function normalizeGraphAttachment(
  attachment: GraphAttachment,
): FacebookAttachment | null {
  const directType = cleanString(attachment.type)?.toLowerCase();
  const mime = cleanString(attachment.mime_type)?.toLowerCase();
  const imageUrl = cleanString(attachment.image_data?.url);
  const videoUrl = cleanString(attachment.video_data?.url);
  const audioUrl = cleanString(attachment.audio_data?.url);
  const fileUrl = cleanString(attachment.file_url);
  const payloadUrl = cleanString(attachment.payload?.url);

  if (imageUrl || directType === "image" || mime?.startsWith("image/")) {
    return {
      type: "image",
      payload: {
        url: imageUrl ?? payloadUrl ?? fileUrl ?? undefined,
        sticker_id: attachment.payload?.sticker_id,
      },
    };
  }

  if (videoUrl || directType === "video" || mime?.startsWith("video/")) {
    return {
      type: "video",
      payload: {
        url: videoUrl ?? payloadUrl ?? fileUrl ?? undefined,
      },
    };
  }

  if (audioUrl || directType === "audio" || mime?.startsWith("audio/")) {
    return {
      type: "audio",
      payload: {
        url: audioUrl ?? payloadUrl ?? fileUrl ?? undefined,
      },
    };
  }

  if (fileUrl || payloadUrl || directType === "file") {
    return {
      type: "file",
      payload: {
        url: fileUrl ?? payloadUrl ?? undefined,
      },
    };
  }

  return null;
}

async function loadExistingPlatformMessageIds(ids: string[]) {
  if (ids.length === 0) {
    return new Set<string>();
  }

  const { data, error } = await supabaseAdmin
    .from("messages")
    .select("platform_message_id")
    .in("platform_message_id", ids);

  if (error) {
    throw new Error(
      `Unable to compare recovered Facebook message IDs: ${error.message}`,
    );
  }

  return new Set(
    (data ?? [])
      .map((row) => cleanString(row.platform_message_id))
      .filter((id): id is string => Boolean(id)),
  );
}

async function recoverMessenger({
  pageId,
  accessToken,
  cutoffMs,
  mode,
}: {
  pageId: string;
  accessToken: string;
  cutoffMs: number;
  mode: FacebookRecoveryMode;
}) {
  const reconnect = mode === "reconnect";
  /*
   * The watchdog numbers were chosen for a three-hour window. Widening it to a
   * day through FACEBOOK_RECOVERY_LOOKBACK_MINUTES multiplies what a single
   * pass has to look at, and the old caps immediately started cutting it
   * short -- one Page found 28 missing messages and stored 12. They are sized
   * for the wider window now.
   */
  const conversationLimit = reconnect ? 100 : 60;
  const messagesPerConversation = reconnect ? 100 : 50;
  const maxMessageRefs = reconnect ? 1_500 : 600;

  /*
   * A ceiling high enough to finish an ordinary day, and a clock to stop it
   * before the function does.
   *
   * Every message costs one sequential Graph call, so a fixed count is really
   * a bet on how fast Meta answers today. 250 was a safe bet and a low one: a
   * Page taking three hundred messages in a day connected and silently got
   * part of it, with nothing to say so. Budgeting time instead lets a busy
   * Page finish while a very busy one stops early and reports it, rather than
   * either being cut short or running until the platform kills it mid-write.
   */
  const maxMessageDetails = reconnect ? 1_200 : 400;
  const deadlineAt =
    Date.now() + (reconnect ? 120_000 : 150_000);
  let token = accessToken;
  let tokenRepaired = false;

  const conversations =
    await facebookGraphJsonWithTokenRecovery<GraphConversationList>({
      pageId,
      path: `${encodeURIComponent(pageId)}/conversations`,
      params: {
        fields: `id,updated_time,messages.limit(${messagesPerConversation}){id,created_time}`,
        limit: conversationLimit,
      },
      accessToken: token,
    });

  token = conversations.accessToken;
  tokenRepaired = tokenRepaired || conversations.tokenRepaired;

  if (!conversations.ok) {
    throw new Error(
      conversations.payload.error?.message ??
        `Unable to list recent Messenger conversations (HTTP ${conversations.status}).`,
    );
  }

  const refs = new Map<string, GraphMessageRef>();

  for (const conversation of conversations.payload.data ?? []) {
    const updatedMs = dateToMs(conversation.updated_time);

    if (updatedMs !== null && updatedMs < cutoffMs) {
      continue;
    }

    for (const message of conversation.messages?.data ?? []) {
      const id = cleanString(message.id);
      const createdMs = dateToMs(message.created_time);

      if (!id || (createdMs !== null && createdMs < cutoffMs)) {
        continue;
      }

      refs.set(id, message);
      if (refs.size >= maxMessageRefs) {
        break;
      }
    }

    if (refs.size >= maxMessageRefs) {
      break;
    }
  }

  const candidateIds = Array.from(refs.keys());
  const existing = await loadExistingPlatformMessageIds(candidateIds);
  const missingIds = candidateIds.filter((id) => !existing.has(id));

  let recovered = 0;
  let failed = 0;

  // Fetch details only for IDs TENH does not already have. This keeps the
  // hourly recovery bounded and avoids unnecessary Graph calls.
  let stoppedEarly = false;

  for (const messageId of missingIds.slice(0, maxMessageDetails)) {
    if (Date.now() > deadlineAt) {
      /*
       * Out of time rather than out of messages. The remainder is not lost --
       * the caller keeps the backfill flag set so the next pass continues from
       * whatever is still missing.
       */
      stoppedEarly = true;
      break;
    }

    try {
      let detail =
        await facebookGraphJsonWithTokenRecovery<GraphMessageDetail>({
          pageId,
          path: encodeURIComponent(messageId),
          params: {
            fields: "id,created_time,from,to,message,attachments",
          },
          accessToken: token,
        });

      token = detail.accessToken;
      tokenRepaired = tokenRepaired || detail.tokenRepaired;

      // Some Graph versions/account types do not expose attachments on the
      // message details edge. Retry with Meta's documented core fields instead
      // of dropping the message entirely.
      if (!detail.ok && detail.payload.error?.code === 100) {
        detail = await facebookGraphJsonWithTokenRecovery<GraphMessageDetail>({
          pageId,
          path: encodeURIComponent(messageId),
          params: {
            fields: "id,created_time,from,to,message",
          },
          accessToken: token,
        });
        token = detail.accessToken;
        tokenRepaired = tokenRepaired || detail.tokenRepaired;
      }

      if (!detail.ok) {
        failed += 1;
        continue;
      }

      const fromId = cleanString(detail.payload.from?.id);
      const recipients = (detail.payload.to?.data ?? [])
        .map((item) => cleanString(item.id))
        .filter((id): id is string => Boolean(id));
      const isEcho = fromId === pageId;
      const customerId = isEcho
        ? recipients.find((id) => id !== pageId) ?? null
        : fromId;

      if (!fromId || !customerId) {
        failed += 1;
        continue;
      }

      const attachments = (detail.payload.attachments?.data ?? [])
        .map(normalizeGraphAttachment)
        .filter((item): item is FacebookAttachment => Boolean(item));
      const text = cleanString(detail.payload.message);
      const createdMs = dateToMs(detail.payload.created_time) ?? Date.now();

      if (createdMs < cutoffMs) {
        continue;
      }

      const event: FacebookMessagingEvent = {
        sender: {
          id: fromId,
        },
        recipient: {
          id: isEcho ? customerId : pageId,
        },
        timestamp: createdMs,
        message: {
          mid: messageId,
          is_echo: isEcho,
          text:
            text ??
            (attachments.length === 0
              ? "[Recovered Messenger message]"
              : undefined),
          attachments: attachments.length > 0 ? attachments : undefined,
        },
      };

      await processFacebookMessage(event);
      recovered += 1;
    } catch (error) {
      failed += 1;
      console.warn(
        "[TENH Facebook Recovery] Unable to recover Messenger message:",
        {
          pageId,
          messageId,
          error:
            error instanceof Error ? error.message : "Unknown error",
        },
      );
    }
  }

  return {
    candidates: missingIds.length,
    recovered,
    failed,
    truncated:
      stoppedEarly ||
      refs.size >= maxMessageRefs ||
      missingIds.length > maxMessageDetails,
    accessToken: token,
    tokenRepaired,
  };
}

async function loadKnownPostIds({
  socialAccountId,
}: {
  socialAccountId: string;
}) {
  const { data, error } = await supabaseAdmin
    .from("conversations")
    .select("facebook_post_id")
    .eq("social_account_id", socialAccountId)
    .not("facebook_post_id", "is", null)
    .order("updated_at", { ascending: false })
    .limit(80);

  if (error) {
    console.warn(
      "[TENH Facebook Recovery] Unable to load known Facebook post IDs:",
      error.message,
    );
    return [] as string[];
  }

  return Array.from(
    new Set(
      (data ?? [])
        .map((row) => cleanString(row.facebook_post_id))
        .filter((id): id is string => Boolean(id)),
    ),
  );
}

async function recoverComments({
  pageId,
  socialAccountId,
  accessToken,
  cutoffMs,
  mode,
}: {
  pageId: string;
  socialAccountId: string;
  accessToken: string;
  cutoffMs: number;
  mode: FacebookRecoveryMode;
}) {
  const reconnect = mode === "reconnect";
  const feedPostLimit = reconnect ? 100 : 20;
  const maxPostIds = reconnect ? 100 : 50;
  const maxCommentCandidates = reconnect ? 400 : 120;
  let token = accessToken;
  let tokenRepaired = false;

  const posts = await facebookGraphJsonWithTokenRecovery<GraphPostList>({
    pageId,
    path: `${encodeURIComponent(pageId)}/feed`,
    params: {
      fields: "id,created_time",
      limit: feedPostLimit,
    },
    accessToken: token,
  });

  token = posts.accessToken;
  tokenRepaired = tokenRepaired || posts.tokenRepaired;

  if (!posts.ok) {
    throw new Error(
      posts.payload.error?.message ??
        `Unable to list Facebook Page posts for recovery (HTTP ${posts.status}).`,
    );
  }

  const knownPostIds = await loadKnownPostIds({
    socialAccountId,
  });
  const postIds = Array.from(
    new Set([
      ...(posts.payload.data ?? [])
        .map((post) => cleanString(post.id))
        .filter((id): id is string => Boolean(id)),
      ...knownPostIds,
    ]),
  ).slice(0, maxPostIds);

  let candidates = 0;
  let recovered = 0;
  let failed = 0;
  const cutoffSeconds = Math.floor(cutoffMs / 1000);

  for (const postId of postIds) {
    try {
      let comments =
        await facebookGraphJsonWithTokenRecovery<GraphCommentList>({
          pageId,
          path: `${encodeURIComponent(postId)}/comments`,
          params: {
            fields: "id,message,from{id,name},created_time,parent{id}",
            filter: "stream",
            limit: 100,
            since: cutoffSeconds,
          },
          accessToken: token,
        });

      token = comments.accessToken;
      tokenRepaired = tokenRepaired || comments.tokenRepaired;

      // Keep recovery compatible if a Graph version rejects `since` on this
      // specific comments edge. The client-side cutoff below still prevents
      // old comments from being imported as part of the hourly safety pass.
      if (!comments.ok && comments.payload.error?.code === 100) {
        comments = await facebookGraphJsonWithTokenRecovery<GraphCommentList>({
          pageId,
          path: `${encodeURIComponent(postId)}/comments`,
          params: {
            fields: "id,message,from{id,name},created_time,parent{id}",
            filter: "stream",
            limit: 100,
          },
          accessToken: token,
        });
        token = comments.accessToken;
        tokenRepaired = tokenRepaired || comments.tokenRepaired;
      }

      if (!comments.ok) {
        failed += 1;
        continue;
      }

      const recentComments = (comments.payload.data ?? []).filter((comment) => {
        const createdMs = dateToMs(comment.created_time);
        return createdMs === null || createdMs >= cutoffMs;
      });
      const ids = recentComments
        .map((comment) => cleanString(comment.id))
        .filter((id): id is string => Boolean(id));
      const existing = await loadExistingPlatformMessageIds(ids);

      for (const comment of recentComments) {
        const commentId = cleanString(comment.id);

        if (!commentId || existing.has(commentId)) {
          continue;
        }

        if (candidates >= maxCommentCandidates) {
          break;
        }
        candidates += 1;

        const value: FacebookFeedCommentValue = {
          item: "comment",
          verb: "add",
          comment_id: commentId,
          post_id: postId,
          parent_id: cleanString(comment.parent?.id) ?? postId,
          message: comment.message ?? "",
          created_time: toUnixSeconds(comment.created_time),
          from:
            cleanString(comment.from?.id) || cleanString(comment.from?.name)
              ? {
                  id: cleanString(comment.from?.id) ?? "",
                  name: cleanString(comment.from?.name) ?? "Facebook User",
                }
              : undefined,
        };

        try {
          await processFacebookComment({
            pageId,
            value,
          });
          recovered += 1;
        } catch (error) {
          failed += 1;
          console.warn(
            "[TENH Facebook Recovery] Unable to recover Facebook comment:",
            {
              pageId,
              postId,
              commentId,
              error:
                error instanceof Error ? error.message : "Unknown error",
            },
          );
        }
      }
    } catch (error) {
      failed += 1;
      console.warn(
        "[TENH Facebook Recovery] Unable to inspect post comments:",
        {
          pageId,
          postId,
          error: error instanceof Error ? error.message : "Unknown error",
        },
      );
    }

    if (candidates >= maxCommentCandidates) {
      break;
    }
  }

  return {
    candidates,
    recovered,
    failed,
    truncated:
      candidates >= maxCommentCandidates ||
      postIds.length >= maxPostIds ||
      (posts.payload.data?.length ?? 0) >= feedPostLimit,
    accessToken: token,
    tokenRepaired,
  };
}

/**
 * Bounded recovery pass used by the Facebook watchdog after a health check.
 * Re-scans a short recent window and inserts only platform IDs missing from
 * TENH, so running it every hour is idempotent and protects against temporary
 * webhook gaps without duplicating conversations/messages/comments.
 */
export async function recoverRecentFacebookData({
  pageId,
  socialAccountId,
  accessToken,
  lookbackMinutes,
  mode = "watchdog",
}: {
  pageId: string;
  socialAccountId: string;
  accessToken: string;
  lookbackMinutes?: number;
  mode?: FacebookRecoveryMode;
}): Promise<FacebookRecoveryResult> {
  const lookback = clampLookbackMinutes(lookbackMinutes, mode);
  const cutoffMs = Date.now() - lookback * 60_000;

  let messenger = {
    candidates: 0,
    recovered: 0,
    failed: 0,
    truncated: false,
    accessToken,
    tokenRepaired: false,
  };

  try {
    messenger = await recoverMessenger({
      pageId,
      accessToken,
      cutoffMs,
      mode,
    });
  } catch (error) {
    messenger.failed += 1;
    console.warn(
      "[TENH Facebook Recovery] Messenger recovery pass failed:",
      {
        pageId,
        error: error instanceof Error ? error.message : "Unknown error",
      },
    );
  }

  let comments = {
    candidates: 0,
    recovered: 0,
    failed: 0,
    truncated: false,
    accessToken: messenger.accessToken,
    tokenRepaired: false,
  };

  try {
    comments = await recoverComments({
      pageId,
      socialAccountId,
      accessToken: messenger.accessToken,
      cutoffMs,
      mode,
    });
  } catch (error) {
    comments.failed += 1;
    console.warn(
      "[TENH Facebook Recovery] Comment recovery pass failed:",
      {
        pageId,
        error: error instanceof Error ? error.message : "Unknown error",
      },
    );
  }

  return {
    messenger: {
      candidates: messenger.candidates,
      recovered: messenger.recovered,
      failed: messenger.failed,
      truncated: messenger.truncated,
    },
    comments: {
      candidates: comments.candidates,
      recovered: comments.recovered,
      failed: comments.failed,
      truncated: comments.truncated,
    },
    tokenRepaired: messenger.tokenRepaired || comments.tokenRepaired,
  };
}
