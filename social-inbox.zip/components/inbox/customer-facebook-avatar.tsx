"use client";
import { useEffect, useRef, useState } from "react";
import { CustomerAvatar } from "@/components/customer-avatar";
import { getFacebookCustomerProfileUrl, normalizeCustomerProfileLink } from "@/lib/facebook/customer-profile-url";
import type { InboxConversation } from "@/types/inbox";

/** Opens only a real stored profile link. Never infers a public ID from a PSID
 * and never invokes the browser extension or forces a manual-link dialog. */
export function CustomerFacebookAvatar({ conversation }: { conversation: InboxConversation }) {
  const contact = conversation.contact;
  const isFacebook = conversation.social_account?.platform === "facebook";
  const pageId = conversation.social_account?.platform_account_id;
  const key = `${conversation.business_id}:${conversation.id}:${contact?.id}`;
  const currentKey = useRef(key); currentKey.current = key;
  const [stored, setStored] = useState<{ key: string; url: string | null } | null>(null);
  const [notice, setNotice] = useState("");
  const safeUrl = (value: unknown) => {
    const url = normalizeCustomerProfileLink(value, contact?.platform_user_id);
    return url && new URL(url).searchParams.get("id") !== pageId ? url : null;
  };
  const url = safeUrl(stored?.key === key ? stored.url : getFacebookCustomerProfileUrl(contact));
  useEffect(() => {
    const controller = new AbortController(); setNotice("");
    if (isFacebook) void fetch(`/api/conversations/${encodeURIComponent(conversation.id)}/facebook-profile`, { cache: "no-store", signal: controller.signal })
      .then(response => response.json()).then(data => {
        if (!controller.signal.aborted && data.success && currentKey.current === key) setStored({ key, url: data.profileUrl ?? null });
      }).catch(() => { /* Normal customer details remain available. */ });
    return () => controller.abort();
  }, [key, conversation.id, isFacebook]);
  if (!contact) return null;
  const image = <CustomerAvatar src={contact.profile_picture_url} name={contact.full_name} contactId={contact.id} platform={conversation.social_account?.platform} eager className="h-full w-full text-2xl" />;
  return <div className="relative flex shrink-0 flex-col items-start gap-1">
    {isFacebook && url ? <a href={url} target="_blank" rel="noopener noreferrer" title="View Facebook profile" aria-label="View customer Facebook profile" className="block h-16 w-16 overflow-hidden rounded-full outline-none ring-offset-2 hover:ring-2 hover:ring-blue-400 focus-visible:ring-2">{image}</a>
      : <button type="button" disabled={!isFacebook} aria-label={isFacebook ? "Facebook profile availability" : "Customer avatar"} onClick={() => setNotice("A public Facebook profile link is not available for this customer. Messenger IDs cannot be used as public profile links.")} className="h-16 w-16 overflow-hidden rounded-full">{image}</button>}
    {notice ? <div role="status" className="absolute left-0 top-[72px] z-30 w-60 rounded-xl border border-slate-200 bg-white p-3 text-xs text-slate-600 shadow-lg"><button type="button" aria-label="Dismiss profile notice" onClick={() => setNotice("")} className="float-right ml-2 px-1">×</button>{notice}</div> : null}
  </div>;
}
