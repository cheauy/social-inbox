"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Clock, Loader2, Search, X } from "lucide-react";
import type { MetaStickerChoice, MetaStickerPack } from "@/lib/stickers/catalog";

const RECENT_KEY = "tenh:meta-messenger-sticker-recents:v1";
const MAX_RECENT = 20;

type Props = {
  conversationId: string;
  disabled: boolean;
  onSend: (choice: MetaStickerChoice) => Promise<boolean>;
  onSent: () => void;
};

function readRecent(): MetaStickerChoice[] {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(RECENT_KEY) || "[]");
    return Array.isArray(parsed) ? parsed.filter((item): item is MetaStickerChoice => item?.provider === "meta" && typeof item.stickerId === "string").slice(0, MAX_RECENT) : [];
  } catch { return []; }
}
function saveRecent(item: MetaStickerChoice) {
  try {
    const next = [item, ...readRecent().filter(saved => saved.stickerId !== item.stickerId)].slice(0, MAX_RECENT);
    sessionStorage.setItem(RECENT_KEY, JSON.stringify(next));
  } catch { /* session storage is optional */ }
}

export function MetaStickerGrid({ conversationId, disabled, onSend, onSent }: Props) {
  const [packs, setPacks] = useState<MetaStickerPack[]>([]);
  const [activePack, setActivePack] = useState<string>("recent");
  const [items, setItems] = useState<MetaStickerChoice[]>([]);
  const [recent, setRecent] = useState<MetaStickerChoice[]>([]);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [sendingId, setSendingId] = useState<string | null>(null);
  const generation = useRef(0), inFlight = useRef(false), strip = useRef<HTMLDivElement>(null);
  const current = useRef({ conversationId, disabled }); current.current = { conversationId, disabled };

  useEffect(() => {
    generation.current++;
    setPacks([]); setItems([]); setQuery(""); setError(""); setSendingId(null); setActivePack("recent");
    setRecent(readRecent());
    const seq = generation.current, target = conversationId, controller = new AbortController();
    if (!disabled) {
      setBusy(true);
      void (async () => {
        try {
          const response = await fetch(`/api/facebook/stickers/packs?${new URLSearchParams({ conversationId: target })}`, { cache: "no-store", signal: controller.signal });
          const data = await response.json();
          if (!response.ok || !data.success || !Array.isArray(data.packs)) throw new Error(`${data.error || "Unable to load Meta sticker packs."}${data.details ? ` ${data.details}` : ""}`);
          if (controller.signal.aborted || generation.current !== seq || current.current.conversationId !== target) return;
          const valid = data.packs.filter((pack: MetaStickerPack) => typeof pack?.packId === "string" && typeof pack?.name === "string");
          setPacks(valid);
          if (!readRecent().length && valid[0]) setActivePack(valid[0].packId);
        } catch (e) {
          if (!controller.signal.aborted && generation.current === seq) setError(e instanceof Error ? e.message : "Meta sticker catalog unavailable.");
        } finally { if (generation.current === seq) setBusy(false); }
      })();
    }
    return () => { controller.abort(); generation.current++; };
  }, [conversationId, disabled]);

  useEffect(() => {
    if (disabled || activePack === "recent" || query.trim().length >= 2) return;
    const seq = ++generation.current, target = conversationId, packId = activePack, controller = new AbortController();
    setBusy(true); setError(""); setItems([]);
    void (async () => {
      try {
        const response = await fetch(`/api/facebook/stickers/pack?${new URLSearchParams({ conversationId: target, packId })}`, { cache: "no-store", signal: controller.signal });
        const data = await response.json();
        if (!response.ok || !data.success || !Array.isArray(data.stickers)) throw new Error(`${data.error || "Unable to load this Meta sticker pack."}${data.details ? ` ${data.details}` : ""}`);
        if (controller.signal.aborted || generation.current !== seq || current.current.conversationId !== target || activePack !== packId) return;
        setItems(data.stickers.filter((item: MetaStickerChoice) => item?.provider === "meta" && typeof item.stickerId === "string"));
      } catch (e) { if (!controller.signal.aborted && generation.current === seq) setError(e instanceof Error ? e.message : "Unable to load Meta stickers."); }
      finally { if (generation.current === seq) setBusy(false); }
    })();
    return () => { controller.abort(); if (generation.current === seq) generation.current++; };
  }, [conversationId, disabled, activePack, query]);

  useEffect(() => {
    const q = query.trim();
    if (disabled || q.length < 2) return;
    const seq = ++generation.current, target = conversationId, controller = new AbortController();
    setBusy(true); setError("");
    const timer = window.setTimeout(() => {
      void (async () => {
        try {
          const response = await fetch(`/api/facebook/stickers/search?${new URLSearchParams({ conversationId: target, q })}`, { cache: "no-store", signal: controller.signal });
          const data = await response.json();
          if (!response.ok || !data.success || !Array.isArray(data.stickers)) throw new Error(`${data.error || "Unable to search Meta stickers."}${data.details ? ` ${data.details}` : ""}`);
          if (controller.signal.aborted || generation.current !== seq || current.current.conversationId !== target) return;
          setItems(data.stickers.filter((item: MetaStickerChoice) => item?.provider === "meta" && typeof item.stickerId === "string"));
        } catch (e) { if (!controller.signal.aborted && generation.current === seq) setError(e instanceof Error ? e.message : "Unable to search Meta stickers."); }
        finally { if (generation.current === seq) setBusy(false); }
      })();
    }, 250);
    return () => { window.clearTimeout(timer); controller.abort(); if (generation.current === seq) generation.current++; };
  }, [conversationId, disabled, query]);

  const shown = useMemo(() => query.trim().length >= 2 ? items : activePack === "recent" ? recent : items, [query, activePack, recent, items]);

  async function send(choice: MetaStickerChoice) {
    if (inFlight.current || current.current.disabled || current.current.conversationId !== conversationId) return;
    const seq = generation.current, target = conversationId;
    inFlight.current = true; setSendingId(choice.stickerId); setError("");
    try {
      const ok = await onSend(choice);
      if (current.current.conversationId !== target || generation.current !== seq) return;
      if (ok) { saveRecent(choice); setRecent(readRecent()); onSent(); }
      else setError("Meta did not confirm this sticker send. Check the conversation before trying again.");
    } catch (e) { if (current.current.conversationId === target) setError(e instanceof Error ? e.message : "Sticker could not be sent."); }
    finally { inFlight.current = false; if (current.current.conversationId === target) setSendingId(null); }
  }

  function selectPack(packId: string) {
    setQuery(""); setError(""); setActivePack(packId);
    strip.current?.querySelector<HTMLElement>(`[data-pack-id="${CSS.escape(packId)}"]`)?.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
  }
  function scrollPacks(direction: -1 | 1) { strip.current?.scrollBy({ left: direction * 180, behavior: "smooth" }); }

  return <div className="flex min-h-0 flex-1 flex-col" data-testid="tenh-meta-stickers">
    <div className="relative mx-3 mb-2 shrink-0">
      <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
      <input value={query} maxLength={100} onChange={event => setQuery(event.target.value)} aria-label="Search Meta Messenger stickers" placeholder="Search Messenger stickers" className="h-9 w-full rounded-xl bg-slate-100 pl-9 pr-8 text-sm text-slate-800 outline-none focus-visible:ring-2 focus-visible:ring-blue-300" />
      {query ? <button type="button" onClick={() => setQuery("")} aria-label="Clear sticker search" className="absolute right-2 top-2 p-0.5 text-slate-500"><X className="h-4 w-4" /></button> : null}
    </div>
    <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-3 py-2" aria-busy={busy || Boolean(sendingId)}>
      {error ? <div role="alert" className="mb-3 rounded-lg bg-amber-50 p-3 text-xs text-amber-800">{error}</div> : null}
      <div className="grid grid-cols-4 gap-2">
        {shown.map(item => <button key={item.stickerId} type="button" disabled={disabled || Boolean(sendingId)} title={item.label} aria-label={`Send sticker: ${item.label}`} onClick={() => void send(item)} className="relative flex aspect-square items-center justify-center rounded-xl p-1 hover:bg-blue-50 focus-visible:outline-2 focus-visible:outline-blue-500 disabled:opacity-40">
          {item.previewUrl ? <img src={item.previewUrl} referrerPolicy="no-referrer" alt={item.label} loading="lazy" className="h-full w-full object-contain" /> : <span className="rounded-lg bg-slate-100 px-2 py-1 text-xs text-slate-500">Sticker</span>}
          {sendingId === item.stickerId ? <Loader2 className="absolute h-6 w-6 animate-spin text-blue-600" /> : null}
        </button>)}
      </div>
      {busy ? <p role="status" className="flex items-center justify-center gap-2 py-6 text-xs text-slate-500"><Loader2 className="h-4 w-4 animate-spin" />Loading Meta stickers…</p> : !shown.length && !error ? <p className="py-8 text-center text-sm text-slate-500">{activePack === "recent" && query.trim().length < 2 ? "Your recently sent Messenger stickers appear here." : "No stickers found."}</p> : null}
    </div>
    <p className="shrink-0 px-4 py-1.5 text-[10px] text-slate-500">Native first-party Messenger stickers from Meta. Your typed text stays in the draft.</p>
    <div className="flex shrink-0 items-center border-t border-slate-200 px-1 py-2">
      <button type="button" aria-label="Previous sticker packs" onClick={() => scrollPacks(-1)} className="flex h-10 w-8 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"><ChevronLeft className="h-5 w-5" /></button>
      <div ref={strip} className="flex min-w-0 flex-1 gap-1 overflow-x-auto scroll-smooth [scrollbar-width:none] [&::-webkit-scrollbar]:hidden" role="tablist" aria-label="Messenger sticker packs">
        <button data-pack-id="recent" type="button" role="tab" aria-selected={activePack === "recent" && query.trim().length < 2} title="Recent" onClick={() => selectPack("recent")} className={`relative flex h-11 min-w-11 items-center justify-center rounded-xl ${activePack === "recent" && query.trim().length < 2 ? "bg-blue-50 ring-1 ring-blue-200" : "hover:bg-slate-50"}`}><Clock className="h-6 w-6 text-blue-500" /></button>
        {packs.map(pack => <button key={pack.packId} data-pack-id={pack.packId} type="button" role="tab" aria-selected={activePack === pack.packId && query.trim().length < 2} title={pack.name} onClick={() => selectPack(pack.packId)} className={`relative flex h-11 min-w-11 items-center justify-center overflow-hidden rounded-xl ${activePack === pack.packId && query.trim().length < 2 ? "bg-blue-50 ring-1 ring-blue-200" : "hover:bg-slate-50"}`}>{pack.previewUrl ? <img src={pack.previewUrl} referrerPolicy="no-referrer" alt="" className="h-9 w-9 object-contain" /> : <span className="text-xs font-semibold text-slate-500">{pack.name.slice(0, 2).toUpperCase()}</span>}</button>)}
      </div>
      <button type="button" aria-label="Next sticker packs" onClick={() => scrollPacks(1)} className="flex h-10 w-8 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"><ChevronRight className="h-5 w-5" /></button>
    </div>
  </div>;
}
