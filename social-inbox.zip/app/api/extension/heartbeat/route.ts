import { NextResponse } from "next/server";

import {
  authenticateDevice,
  recordExtensionEvent,
} from "@/lib/extension/device-auth";
import { resolvePage } from "@/lib/extension/facebook-thread";
import { supabaseAdmin } from "@/lib/supabase/admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_TEXT = 300;

/* The words the extension shows its own customer, kept identical here so the
   website cannot describe the same browser differently. */
const COMPANION_STATES = new Set([
  "ready",
  "sleeping",
  "connecting",
  "sign_in_required",
  "error",
]);

function isUnknownColumn(error: { code?: string; message?: string }) {
  return (
    error.code === "42703" ||
    error.code === "PGRST204" ||
    /column .* does not exist|could not find the .* column/i.test(
      error.message ?? "",
    )
  );
}

function clean(value: unknown) {
  return typeof value === "string" && value.trim()
    ? value.trim().slice(0, MAX_TEXT)
    : null;
}

/*
 * What a paired browser is looking at, as it sees it.
 *
 * Everything here is an observation, and the wording in TENH says so: a
 * composer this reports as available is a composer the extension found in a
 * Facebook tab a moment ago, not a promise that a message will send. Nothing
 * in the Inbox, the send routes or the webhooks reads any of it.
 *
 * The URL is stored with its query string removed. A Facebook URL can carry
 * ids and referral parameters, and none of that is needed to say "this browser
 * is on Business Suite".
 */
export async function POST(request: Request) {
  const auth = await authenticateDevice(request);

  if (!auth.success) {
    return NextResponse.json(
      { success: false, error: auth.error },
      { status: auth.status },
    );
  }

  let body: {
    facebookConnected?: unknown;
    pageId?: unknown;
    pageName?: unknown;
    url?: unknown;
    composerState?: unknown;
    facebookState?: unknown;
    keepCompanionActive?: unknown;
    extensionVersion?: unknown;
    event?: unknown;
  };

  try {
    body = (await request.json()) as typeof body;
  } catch {
    body = {};
  }

  const device = auth.device;
  const now = new Date().toISOString();

  const rawUrl = clean(body.url);
  let url: string | null = null;

  if (rawUrl) {
    try {
      const parsed = new URL(rawUrl);
      url = `${parsed.origin}${parsed.pathname}`;
    } catch {
      url = null;
    }
  }

  const composerState = clean(body.composerState);
  const facebookState = clean(body.facebookState);

  const base = {
    last_seen_at: now,
    updated_at: now,
    facebook_connected: body.facebookConnected === true,
    current_page_id: clean(body.pageId),
    current_page_name: clean(body.pageName),
    current_url: url,
    composer_state:
      composerState === "available" ||
      composerState === "unavailable" ||
      composerState === "unknown"
        ? composerState
        : "unknown",
    extension_version: clean(body.extensionVersion) ?? device.extension_version,
  };

  const withCompanionState = {
    ...base,
    facebook_state: COMPANION_STATES.has(facebookState ?? "")
      ? facebookState
      : null,
    keep_companion_active: body.keepCompanionActive === true,
  };

  /*
   * Written with the newer columns when the database has them, and without
   * when it does not.
   *
   * A heartbeat is the thing that keeps a browser looking alive, and code
   * reaches production before a migration does. Failing the whole request over
   * a column that is one migration away would take every paired browser
   * offline on the website for no reason a customer could act on -- so the
   * richer write is attempted, and a missing column falls back rather than
   * 500s. The fallback stops being reached the moment the migration lands.
   */
  let { error } = await supabaseAdmin
    .from("extension_devices")
    .update(withCompanionState)
    .eq("id", device.id);

  if (error && isUnknownColumn(error)) {
    ({ error } = await supabaseAdmin
      .from("extension_devices")
      .update(base)
      .eq("id", device.id));
  }

  if (error) {
    return NextResponse.json(
      { success: false, error: "Unable to record this heartbeat." },
      { status: 500 },
    );
  }

  /*
   * Only a named change is written to the log. A heartbeat every half minute
   * is not an event; "this browser lost Facebook" is.
   */
  const event = clean(body.event);

  if (event) {
    void recordExtensionEvent({
      businessId: device.business_id,
      deviceId: device.id,
      memberId: device.member_id,
      userId: device.user_id,
      eventType: event,
      status: "ok",
      metadata: {
        pageId: clean(body.pageId),
        composerState,
      },
    });
  }

  /*
   * Which of the workspace's Pages this browser is on. Recorded by id, never
   * by name: a Page the workspace has not connected simply does not match, and
   * the browser is told nothing about it.
   */
  const page = await resolvePage(device.business_id, clean(body.pageId));

  if (page) {
    await supabaseAdmin
      .from("extension_device_pages")
      .upsert(
        {
          device_id: device.id,
          business_id: device.business_id,
          social_account_id: page.socialAccountId,
          page_id: page.pageId,
          enabled: true,
        },
        { onConflict: "device_id,page_id" },
      );
  }

  /*
   * The badge number, taken from the column the Inbox and the phone already
   * read. The extension does not count anything itself -- a second unread
   * system is a second number to disagree with the first.
   */
  const { data: unreadRows } = await supabaseAdmin
    .from("conversations")
    .select("unread_count")
    .eq("business_id", device.business_id)
    .gt("unread_count", 0);

  const unreadTotal = (unreadRows ?? []).reduce(
    (total, row) => total + Math.max(0, (row.unread_count as number) ?? 0),
    0,
  );

  return NextResponse.json({
    success: true,
    acknowledgedAt: now,
    unreadTotal,
    pageMatched: Boolean(page),
    pageName: page?.pageName ?? null,
  });
}
