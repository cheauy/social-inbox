export type ConversationStatus =
  | "open"
  | "pending"
  | "resolved"
  | "closed"
  | "spam";

export type MessageDirection =
  | "incoming"
  | "outgoing";

export type TeamMemberRole =
  | "owner"
  | "admin"
  | "agent";

export type TagColor = string;

export type TeamMember = {
  id: string;
  business_id?: string;
  full_name: string;
  email: string;
  role: string;
  profile_picture_url: string | null;
};

export type SavedReplyAttachmentType =
  | "image"
  | "video";

/*
 * Quick reply media, as stored in saved_replies.attachments.
 *
 * A handful of small records that are always read with their reply, so they
 * live in the row rather than a table of their own -- one write saves a reply
 * and its media together, and there is no join to keep in step.
 *
 * `path` is a key in the private media bucket, never a URL: the file is reached
 * through /api/saved-replies/media, which checks the path belongs to the
 * caller's workspace and signs a short-lived link.
 */
export type SavedReplyAttachment = {
  path: string;
  kind: SavedReplyAttachmentType;
  name: string;
  size: number;
  mimeType: string;

  /*
   * A short-lived signed link, attached when the API reads the reply.
   *
   * Not stored -- the row holds only the path. It travels with the reply so a
   * list of them costs one request instead of one per attachment: a picker
   * showing twenty replies was asking for forty signed links before it could
   * draw a thumbnail.
   */
  url?: string | null;
};

export type CustomerTag = {
  id: string;
  business_id: string;
  name: string;
  color: TagColor;
  sort_index: number;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export type ConversationActivityType =
  | "status_changed"
  | "assigned"
  | "unassigned"
  | "pinned"
  | "unpinned"
  | "tag_added"
  | "tag_removed"
  | "note_added"
  | "note_updated"
  | "note_deleted"
  | "internal_note_added"
  | "internal_note_updated"
  | "internal_note_deleted"
  | "customer_profile_updated"
  | "customer_updated";

export type ConversationActivity = {
  id: string;
  business_id: string;
  conversation_id: string;
  contact_id: string | null;
  actor_member_id: string | null;

  activity_type:
    ConversationActivityType;

  title: string;
  description: string | null;

  customer_name: string | null;
  actor_name: string | null;

  actor_profile_picture_url:
    string | null;

  metadata: Record<string, unknown>;

  created_at: string;
};

export type InboxContact = {
  id: string;
  business_id: string;
  full_name: string | null;
  profile_picture_url: string | null;
  platform_user_id: string;
  facebook_profile_id?: string | null;
  phone: string | null;
  email: string | null;
  company_name: string | null;
  customer_note: string | null;
  created_at: string;
  last_contact_at: string | null;
  address: string | null;
  tags: CustomerTag[];
};

/*
 * A quick reply category.
 *
 * Replies still record their category by name, so this table exists to give
 * those names an order, a spelling worth trusting, and somewhere to rename or
 * remove them from.
 */
export type SavedReplyCategory = {
  id: string;
  business_id: string;
  name: string;
  sort_index: number;
  created_at: string;
  updated_at: string;
};

export type SavedReply = {
  id: string;
  business_id: string;
  title: string;
  shortcut: string | null;
  message_text: string;
  category: string | null;
  sort_index: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;

  attachments: SavedReplyAttachment[];
};

export type ContactNote = {
  id: string;
  contact_id: string;
  author_id: string;
  note_text: string;
  created_at: string;
  updated_at: string;
  author: TeamMember | null;
};

export type InboxConversation = {
  id: string;
  business_id: string;
  subscription_id?: string | null;
  status: ConversationStatus;
  unread_count: number;
  last_message_text: string | null;
  last_message_at: string | null;
  is_pinned: boolean;
  pinned_at: string | null;
  pinned_by: string | null;

  latest_message_type:
    | "text"
    | "image"
    | "video"
    | "audio"
    | "file"
    | "sticker"
    | "unknown"
    | null;

  latest_message_direction:
    | MessageDirection
    | null;

  assigned_to: string | null;
  assigned_at: string | null;
  assigned_member: TeamMember | null;
  contact: InboxContact | null;
  seen_by_member?: TeamMember | null;
  seen_at?: string | null;
  
  source_type:
  | "messenger"
  | "comment";

facebook_post_id:
  | string
  | null;

facebook_comment_id:
  | string
  | null;

parent_comment_id:
  | string
  | null;

  social_account: {
    id: string;
    account_name: string;
    platform?: string;
    platform_account_id: string;
  } | null;
};

/*
 * What the phone is sent for each conversation.
 *
 * The web Inbox reads a conversation's assignee, its pin metadata, the
 * comment ids that tie it to a Facebook post, and the customer's whole
 * record. The phone reads ten fields and six across the two joins, and it is
 * sent every conversation in the workspace at once -- 488 of them here, which
 * is 520kB of the full shape and 247kB of this one. Half a megabyte over a
 * Cambodian mobile connection to draw a list of names is not a trade worth
 * making, so the mobile bootstrap projects down to this.
 *
 * Kept beside InboxConversation on purpose: the day the phone needs another
 * field, the two are read together and the projection is one line away.
 */
export type MobileConversation = Pick<
  InboxConversation,
  | "id"
  | "business_id"
  | "status"
  | "unread_count"
  | "last_message_text"
  | "last_message_at"
  | "is_pinned"
  | "assigned_to"
  | "source_type"
  | "facebook_post_id"
  | "facebook_comment_id"
  | "parent_comment_id"
> & {
  contact:
    | (Pick<InboxContact, "id" | "full_name" | "profile_picture_url" | "phone" | "platform_user_id"> & {
        /*
         * Just enough of a tag to draw a chip. The list shows them under the
         * preview, and the full record is a request away in the panel.
         */
        tags: Pick<CustomerTag, "id" | "name" | "color">[];
      })
    | null;

  social_account: {
    id: string;
    platform?: string;
    platform_account_id: string;

    // The Page's name, shown in the customer panel's Facebook section.
    account_name: string;
  } | null;
};

export type InboxMessage = {
  id: string;
  platform_message_id: string;
  conversation_id: string;
  sender_type: string;
  sender_platform_id: string;
  recipient_platform_id: string;
  direction: MessageDirection;
  message_type: string;
  message_text: string | null;
  attachment_url: string | null;
  raw_payload: Record<
  string,
  unknown
> | null;
  platform_created_at: string | null;
  created_at: string;
  comment_is_liked: boolean;
comment_is_hidden: boolean;
comment_is_deleted: boolean;
comment_deleted_by:
  | "customer"
  | "page"
  | null;
delivery_status:
  | "sent"
  | "delivered"
  | "seen"
  | null;

delivered_at:
  | string
  | null;

seen_at:
  | string
  | null;
};
