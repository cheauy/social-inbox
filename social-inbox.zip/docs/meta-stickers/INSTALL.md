# TENH — Meta Messenger Sticker API patch

## Scope

This patch changes only TENH's **Facebook Messenger sticker flow**.

- Facebook: native Meta first-party Messenger sticker packs/search/send.
- Telegram: existing native Telegram sticker flow is unchanged.
- Chrome Companion/profile resolver: unchanged and not included.
- Existing Inbox, quick replies, replies, block rules and messaging-window checks are reused.

## Install

1. Back up/commit the current TENH repository.
2. Merge this ZIP into the project root, preserving folder names.
3. Run `db/migrations/202609130001_meta_messenger_sticker_receipts.sql` in the existing Supabase database. It is idempotent and safe if the earlier receipt table already exists.
4. `STIPOP_API_KEY`, `STIPOP_LANGUAGE`, `STIPOP_COUNTRY`, and `STIPOP_MEDIA_HOSTS` are no longer required by the active Facebook sticker flow and may be removed from Vercel after the new deployment is confirmed.
5. Run the project's locked install/build workflow (`npm run build`) and test a preview deployment before production.
6. Refresh TENH after deployment. No Chrome extension reload is required for this sticker-only patch.

## New Facebook routes

- `GET /api/facebook/stickers/packs?conversationId=...`
- `GET /api/facebook/stickers/pack?conversationId=...&packId=...`
- `GET /api/facebook/stickers/search?conversationId=...&q=...`
- `POST /api/facebook/stickers/send`

Page access tokens remain server-side. The selected conversation determines the connected Facebook Page and token; nothing is hardcoded to one Page.

## Sending

TENH sends a native Meta catalog sticker by `sticker_id` through the existing Messenger `/{PAGE_ID}/messages` send endpoint. It does not download the sticker and resend it as an image.

The send route reuses TENH's customer-block check and Messenger reply-window policy, refreshes expired Page tokens when possible, and uses `facebook_sticker_sends` as a duplicate/uncertain-send fence.

## Retired routes

The old `/api/stickers/search` and `/api/stickers/send` external-provider routes now return HTTP 410 and tell stale clients to refresh. This prevents old cached TENH UI code from continuing to call the former provider.

Compatibility type exports are retained in `lib/stickers/catalog.ts` only so an old unused component/server file does not break TypeScript compilation. The active Facebook UI/API does not import or call that provider.

## Meta API note

The implementation is based on Meta's Messenger Sticker API documentation supplied for this project:
`https://developers.facebook.com/documentation/business-messaging/messenger-platform/send-messages/sticker-api/`

Meta's documentation page could not be fetched from the validation environment, so live catalog requests against your Page were not verified here. Catalog access is centralized in `lib/stickers/meta-messenger-server.ts`; if Meta returns a different documented edge for your app/version, TENH will show the provider error instead of silently switching to image stickers.

## Validation performed

- 8 focused Node static/contract checks passed.
- 12 changed/new TS/TSX files syntax-transpiled with TypeScript: 0 syntax errors.
- Merged baseline (existing uploaded project + prior sticker patch + this patch): 521 TS/TSX files syntax-transpiled, 0 syntax errors.
- No `tenh-extension/` file is present in this patch.
- Full Next.js production build and live Meta Page calls were not run in this environment.
